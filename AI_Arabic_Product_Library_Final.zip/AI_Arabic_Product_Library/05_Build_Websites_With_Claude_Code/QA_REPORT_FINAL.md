# QA_REPORT_FINAL — ابن موقعك الأول مع Claude Code

| Field | Result |
|---|---|
| Product | ابن موقعك الأول مع Claude Code |
| Files | `Build_Websites_With_Claude_Code_Arabic_Final.docx` · `Build_Websites_With_Claude_Code_Arabic_Final.pdf` |
| Research verified at | 6 سبتمبر 2026 |
| Official sources checked | nextjs.org (stable release line), react.dev/versions, nodejs.org (release schedule and LTS status), the Node 24 node:sqlite stability index, astro.build and svelte.dev for the stack comparison, and code.claude.com/docs for the Claude Code workflow |
| Latest feature verification status | Every current-feature claim has a record in `_work/research/current_features.json`. Claims that could not be verified are listed under `not_verified_do_not_claim` in that file and are NOT stated as fact in the product. |
| DOCX pages | 38 (rendered through LibreOffice Writer) |
| PDF pages | 37 |
| Prompt count | n/a — this product is a guide, not a prompt pack |
| Prompt numbering | n/a |
| RTL (PDF) | PASS — page direction is `rtl`; every page rendered and inspected right-aligned with the text block starting at the right edge |
| RTL (DOCX) | PASS — `w:bidi` set on the section and on 585 paragraphs; verified by re-parsing the saved file |
| Right alignment | PASS — verified visually on every rendered page |
| Arabic shaping | PASS — letters joined, no isolated forms; verified on the full-page renders of all 37 PDF pages |
| Arabic dots | PASS — verified on the full-page renders; no dotless glyphs found |
| Arabic presentation forms in the text layer | PASS — none — copied text yields base Arabic letters, not U+FE7x/U+FBxx forms |
| Mixed Arabic/English | PASS — Latin terms render inline without flipping the Arabic line; verified visually and by extraction |
| Variables `[…]` | PASS — 6 distinct variables, all intact in the text layer and findable by PDF search |
| Variables containing digits | PASS — none — digits inside brackets are rejected by the build because they break bracket order on copy |
| Brackets | PASS — no reversed `]…[` pattern; every `[متغير]` copies with both brackets attached |
| Code blocks | PASS — `direction: ltr` with `unicode-bidi: isolate`; terminal commands render left-to-right inside the RTL page, in JetBrains Mono |
| Lists | PASS — bullets and numbers on the right, verified on the renders |
| Tables | PASS — `bidiVisual` in DOCX, `direction: rtl` in PDF; first column on the right |
| Images | n/a — this product contains no raster images; all page furniture is vector |
| Fonts | CRZFJS+PlexAr-Semi-Bold, FNPUCG+PlexAr-Medium, HIRYNU+PlexAr-Bold, NETSUB+PlexMono, TFCPFR+PlexAr, UWGIWA+DejaVu-Sans-Bold, WDHEQY+PlexMono-Bold |
| PDF font embedding | PASS — all 7 subsets embedded, no substitution |
| TOC (PDF) | PASS — generated with `target-counter`, so page numbers are computed from the final laid-out pages, not typed by hand |
| TOC links (PDF) | PASS — 264 internal link annotations, every one resolving to a page inside the document |
| TOC (DOCX) | NOT TESTED as page numbers — a live Word `TOC` field is inserted; Word or LibreOffice fills it when fields are updated (F9). Static page numbers were deliberately not baked in, because DOCX pagination differs from the PDF. |
| Selectable text | PASS — every content page carries a real text layer; no page is an image |
| Searchable text | PASS — 129/129 sampled Arabic words found by PDF search across the whole document |
| Copy test | PASS — all 1283 distinct Arabic words of the canonical source were found in the extracted text layer; sampled from the beginning, middle and end of the document, and from prompt boxes |
| Mobile readability | PASS with a note — body text is 11.7pt on A4 with 1.95 line height, headings 15pt+, prompt boxes 10.4pt. Pages were re-rendered at 390px width (phone class) and checked: headings, prompt boxes and code are legible without zoom; body text is comfortable after light zoom, which is inherent to any A4 page on a phone. |
| Cover | PASS with a documented deviation — see Known limitations |
| Copyright page | PASS — a dedicated `حقوق النشر` page naming برومبتات عربية and https://t.me/PromptsArabic |
| Footer copyright | PASS — every page footer carries `PromptsArabic · t.me/PromptsArabic` plus the page number |
| Telegram link present | PASS — appears 39 times in the PDF text layer and 3 times in the DOCX |
| Telegram link clickable | PASS — 2 URI link annotations resolving to https://t.me/PromptsArabic, read back from the saved PDF |
| Owner name present | PASS — 5 times in the PDF, 5 times in the DOCX |
| Empty pages | PASS — none |
| Overflow / clipping | PASS — no text block falls outside the safe area on any page |
| Pages visually inspected | 37/37 PDF pages and 38/38 DOCX pages — every page was rendered to PNG and reviewed as a contact sheet, with individual pages opened at full size |
| DOCX editability | PASS — real named paragraph styles (APL Body, APL Bullet, APL Callout, APL Caption, APL Code, APL H1, APL H2, APL H3, APL Lead, APL Prompt, APL PromptLbl, APL Subtitle, APL Title) rather than per-paragraph manual formatting |
| Critical remaining | 0 |
| Major remaining | 0 |
| Ready | YES |

## Issues discovered and fixed during the build

- The stack was chosen by comparison, not by popularity: Next.js, React with Vite, Astro and SvelteKit were compared on the criteria that matter for this project, and the decision is written with its reasons and with the cases where it would be the wrong choice.
- SvelteKit 3 was excluded because it was a release candidate at the time of the research, and the guide states that reason explicitly rather than silently omitting it. The same rule ruled out presenting Node 24 built-in node:sqlite as the stable path: its stability index reads 1.2, release candidate, so the guide says so and points at a stable driver instead.
- The version cell for Next.js was written as 16.3.x. In an RTL table cell the trailing Latin letter after digits is reordered to the front and the cell rendered as x.16.3. Caught on visual inspection of page 14, the cell was rewritten as a plain number, and the engine now rejects any version token ending in a Latin letter after digits inside Arabic text so the pattern cannot return. All five products were rebuilt and re-verified after the guard was added.
- Every one of the ten phases uses the same structure: what we build, the exact prompt to send, the files to expect, how to test it yourself, the likely mistakes, and a gate that must pass before moving on.

## Known limitations

- **Cover is editorial, not photographic.** The brief asks for a photographic cover. This build environment allows outbound network access only to package registries (npm, PyPI, crates.io); every image host — including licensed stock libraries — is blocked by the egress proxy, and no image-generation tool is available. Rather than ship an unlicensed or low-quality image, the cover is a typographic/editorial design built as vector: full-bleed gradient, hairline grid, title, contents strip, promise chips and the owner mark. It was checked at Telegram-thumbnail size and the title reads in under a second. `_work/research/image_sources.json` records why no image source could be used.
- **DOCX table of contents shows page numbers only after a field update.** The file carries a live Word TOC field; pressing F9 in Word fills it. This is intentional: hard-coding PDF page numbers into the DOCX would be wrong, because Word repaginates.
- **Full-line copy order in non-bidi-aware extractors.** The PDF stores RTL runs in visual order, as every PDF does. Word-level and variable-level copy and search were tested and pass. A line that mixes Arabic with Western digits can come back with the digit run repositioned when pulled through a text extractor that does not implement the Unicode Bidi Algorithm; readers that do implement it reconstruct the line correctly. Line-final punctuation after a variable is removed by the build for this reason.
- **The example project was not built end to end in this environment.** The phases, prompts, file lists and test steps were written against the official documentation of the chosen stack, but no Next.js project was scaffolded or run as part of producing this guide. Verify each phase gate as you work through it, and check the current stable versions before you start, as the guide instructs.

---

_برومبتات عربية — https://t.me/PromptsArabic_
